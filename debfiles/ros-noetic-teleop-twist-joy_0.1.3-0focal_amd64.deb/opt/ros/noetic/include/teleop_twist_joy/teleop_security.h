#include <string>
#include <vector>
#include <iostream>

#include "ros/ros.h"
#include "ros/topic.h"

#include "sensor_msgs/Joy.h"
#include "std_msgs/Bool.h"


class TeleopSecurity
{
public:
    TeleopSecurity();
    ~TeleopSecurity();

private:
    void rosCbJoy(const sensor_msgs::Joy joy_msg);
    void rosCbTelopCmd(const std_msgs::Bool cmd_msg);

    ros::Publisher ros_pub_joy_security_;

    // Members
    bool teleop_cmd_;
    bool teleop_security_activate_;
    bool use_touch_code_;
    int cpt_same_joy_cmd_;
    int max_cpt_same_joy_cmd_;
    int step_desactivate_;

    std::vector<int> buttons_step_0_{std::vector<int>(15, 0)};
    std::vector<int> buttons_step_1_{std::vector<int>(15, 0)};
    std::vector<int> buttons_step_2_{std::vector<int>(15, 0)};
    std::vector<int> buttons_step_3_{std::vector<int>(15, 0)};
    std::vector<int> buttons_step_4_{std::vector<int>(15, 0)};

    sensor_msgs::Joy old_joy_in_;

    ros::Subscriber ros_sub_joy_;
    ros::Subscriber ros_sub_teleop_cmd_;
};