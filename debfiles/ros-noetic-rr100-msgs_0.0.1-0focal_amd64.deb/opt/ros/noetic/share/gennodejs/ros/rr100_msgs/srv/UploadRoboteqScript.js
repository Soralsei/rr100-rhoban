// Auto-generated. Do not edit!

// (in-package rr100_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class UploadRoboteqScriptRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.serialport = null;
      this.baudrate = null;
      this.script_path = null;
      this.checksum = null;
    }
    else {
      if (initObj.hasOwnProperty('serialport')) {
        this.serialport = initObj.serialport
      }
      else {
        this.serialport = '';
      }
      if (initObj.hasOwnProperty('baudrate')) {
        this.baudrate = initObj.baudrate
      }
      else {
        this.baudrate = 0;
      }
      if (initObj.hasOwnProperty('script_path')) {
        this.script_path = initObj.script_path
      }
      else {
        this.script_path = '';
      }
      if (initObj.hasOwnProperty('checksum')) {
        this.checksum = initObj.checksum
      }
      else {
        this.checksum = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type UploadRoboteqScriptRequest
    // Serialize message field [serialport]
    bufferOffset = _serializer.string(obj.serialport, buffer, bufferOffset);
    // Serialize message field [baudrate]
    bufferOffset = _serializer.int64(obj.baudrate, buffer, bufferOffset);
    // Serialize message field [script_path]
    bufferOffset = _serializer.string(obj.script_path, buffer, bufferOffset);
    // Serialize message field [checksum]
    bufferOffset = _serializer.int64(obj.checksum, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type UploadRoboteqScriptRequest
    let len;
    let data = new UploadRoboteqScriptRequest(null);
    // Deserialize message field [serialport]
    data.serialport = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [baudrate]
    data.baudrate = _deserializer.int64(buffer, bufferOffset);
    // Deserialize message field [script_path]
    data.script_path = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [checksum]
    data.checksum = _deserializer.int64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.serialport);
    length += _getByteLength(object.script_path);
    return length + 24;
  }

  static datatype() {
    // Returns string type for a service object
    return 'rr100_msgs/UploadRoboteqScriptRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '5b4ab20e58fd4bb92bef5a30f964b527';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string serialport   # 
    int64 baudrate      # 
    string script_path  #
    int64 checksum      #
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new UploadRoboteqScriptRequest(null);
    if (msg.serialport !== undefined) {
      resolved.serialport = msg.serialport;
    }
    else {
      resolved.serialport = ''
    }

    if (msg.baudrate !== undefined) {
      resolved.baudrate = msg.baudrate;
    }
    else {
      resolved.baudrate = 0
    }

    if (msg.script_path !== undefined) {
      resolved.script_path = msg.script_path;
    }
    else {
      resolved.script_path = ''
    }

    if (msg.checksum !== undefined) {
      resolved.checksum = msg.checksum;
    }
    else {
      resolved.checksum = 0
    }

    return resolved;
    }
};

class UploadRoboteqScriptResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.success = null;
      this.message = null;
    }
    else {
      if (initObj.hasOwnProperty('success')) {
        this.success = initObj.success
      }
      else {
        this.success = false;
      }
      if (initObj.hasOwnProperty('message')) {
        this.message = initObj.message
      }
      else {
        this.message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type UploadRoboteqScriptResponse
    // Serialize message field [success]
    bufferOffset = _serializer.bool(obj.success, buffer, bufferOffset);
    // Serialize message field [message]
    bufferOffset = _serializer.string(obj.message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type UploadRoboteqScriptResponse
    let len;
    let data = new UploadRoboteqScriptResponse(null);
    // Deserialize message field [success]
    data.success = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [message]
    data.message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.message);
    return length + 5;
  }

  static datatype() {
    // Returns string type for a service object
    return 'rr100_msgs/UploadRoboteqScriptResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '937c9679a518e3a18d831e57125ea522';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool success        #
    string message      #
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new UploadRoboteqScriptResponse(null);
    if (msg.success !== undefined) {
      resolved.success = msg.success;
    }
    else {
      resolved.success = false
    }

    if (msg.message !== undefined) {
      resolved.message = msg.message;
    }
    else {
      resolved.message = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: UploadRoboteqScriptRequest,
  Response: UploadRoboteqScriptResponse,
  md5sum() { return 'f2fbcf40c4dd266686851d8316d54857'; },
  datatype() { return 'rr100_msgs/UploadRoboteqScript'; }
};
