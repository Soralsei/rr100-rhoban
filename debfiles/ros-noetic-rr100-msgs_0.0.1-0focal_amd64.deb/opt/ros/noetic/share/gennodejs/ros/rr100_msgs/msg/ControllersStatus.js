// Auto-generated. Do not edit!

// (in-package rr100_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class ControllersStatus {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.name = null;
      this.estop_soft = null;
      this.estop_hard = null;
      this.overheat = null;
      this.overvoltage = null;
      this.undervoltage = null;
      this.short_detect = null;
      this.stall = null;
      this.amplimit = null;
      this.safetymotor = null;
      this.brake = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('name')) {
        this.name = initObj.name
      }
      else {
        this.name = [];
      }
      if (initObj.hasOwnProperty('estop_soft')) {
        this.estop_soft = initObj.estop_soft
      }
      else {
        this.estop_soft = [];
      }
      if (initObj.hasOwnProperty('estop_hard')) {
        this.estop_hard = initObj.estop_hard
      }
      else {
        this.estop_hard = [];
      }
      if (initObj.hasOwnProperty('overheat')) {
        this.overheat = initObj.overheat
      }
      else {
        this.overheat = [];
      }
      if (initObj.hasOwnProperty('overvoltage')) {
        this.overvoltage = initObj.overvoltage
      }
      else {
        this.overvoltage = [];
      }
      if (initObj.hasOwnProperty('undervoltage')) {
        this.undervoltage = initObj.undervoltage
      }
      else {
        this.undervoltage = [];
      }
      if (initObj.hasOwnProperty('short_detect')) {
        this.short_detect = initObj.short_detect
      }
      else {
        this.short_detect = [];
      }
      if (initObj.hasOwnProperty('stall')) {
        this.stall = initObj.stall
      }
      else {
        this.stall = [];
      }
      if (initObj.hasOwnProperty('amplimit')) {
        this.amplimit = initObj.amplimit
      }
      else {
        this.amplimit = [];
      }
      if (initObj.hasOwnProperty('safetymotor')) {
        this.safetymotor = initObj.safetymotor
      }
      else {
        this.safetymotor = [];
      }
      if (initObj.hasOwnProperty('brake')) {
        this.brake = initObj.brake
      }
      else {
        this.brake = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ControllersStatus
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [name]
    bufferOffset = _arraySerializer.string(obj.name, buffer, bufferOffset, null);
    // Serialize message field [estop_soft]
    bufferOffset = _arraySerializer.bool(obj.estop_soft, buffer, bufferOffset, null);
    // Serialize message field [estop_hard]
    bufferOffset = _arraySerializer.bool(obj.estop_hard, buffer, bufferOffset, null);
    // Serialize message field [overheat]
    bufferOffset = _arraySerializer.bool(obj.overheat, buffer, bufferOffset, null);
    // Serialize message field [overvoltage]
    bufferOffset = _arraySerializer.bool(obj.overvoltage, buffer, bufferOffset, null);
    // Serialize message field [undervoltage]
    bufferOffset = _arraySerializer.bool(obj.undervoltage, buffer, bufferOffset, null);
    // Serialize message field [short_detect]
    bufferOffset = _arraySerializer.bool(obj.short_detect, buffer, bufferOffset, null);
    // Serialize message field [stall]
    bufferOffset = _arraySerializer.bool(obj.stall, buffer, bufferOffset, null);
    // Serialize message field [amplimit]
    bufferOffset = _arraySerializer.bool(obj.amplimit, buffer, bufferOffset, null);
    // Serialize message field [safetymotor]
    bufferOffset = _arraySerializer.bool(obj.safetymotor, buffer, bufferOffset, null);
    // Serialize message field [brake]
    bufferOffset = _arraySerializer.bool(obj.brake, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ControllersStatus
    let len;
    let data = new ControllersStatus(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [name]
    data.name = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [estop_soft]
    data.estop_soft = _arrayDeserializer.bool(buffer, bufferOffset, null)
    // Deserialize message field [estop_hard]
    data.estop_hard = _arrayDeserializer.bool(buffer, bufferOffset, null)
    // Deserialize message field [overheat]
    data.overheat = _arrayDeserializer.bool(buffer, bufferOffset, null)
    // Deserialize message field [overvoltage]
    data.overvoltage = _arrayDeserializer.bool(buffer, bufferOffset, null)
    // Deserialize message field [undervoltage]
    data.undervoltage = _arrayDeserializer.bool(buffer, bufferOffset, null)
    // Deserialize message field [short_detect]
    data.short_detect = _arrayDeserializer.bool(buffer, bufferOffset, null)
    // Deserialize message field [stall]
    data.stall = _arrayDeserializer.bool(buffer, bufferOffset, null)
    // Deserialize message field [amplimit]
    data.amplimit = _arrayDeserializer.bool(buffer, bufferOffset, null)
    // Deserialize message field [safetymotor]
    data.safetymotor = _arrayDeserializer.bool(buffer, bufferOffset, null)
    // Deserialize message field [brake]
    data.brake = _arrayDeserializer.bool(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    object.name.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    length += object.estop_soft.length;
    length += object.estop_hard.length;
    length += object.overheat.length;
    length += object.overvoltage.length;
    length += object.undervoltage.length;
    length += object.short_detect.length;
    length += object.stall.length;
    length += object.amplimit.length;
    length += object.safetymotor.length;
    length += object.brake.length;
    return length + 44;
  }

  static datatype() {
    // Returns string type for a message object
    return 'rr100_msgs/ControllersStatus';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '806763f0b4e36e3b69be4a3e8c4faddb';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # This is a message that holds different status from the controller 
    
    Header header
    
    string[] name
    bool[] estop_soft
    bool[] estop_hard
    bool[] overheat
    bool[] overvoltage
    bool[] undervoltage
    bool[] short_detect
    bool[] stall
    bool[] amplimit
    bool[] safetymotor
    bool[] brake
    
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ControllersStatus(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.name !== undefined) {
      resolved.name = msg.name;
    }
    else {
      resolved.name = []
    }

    if (msg.estop_soft !== undefined) {
      resolved.estop_soft = msg.estop_soft;
    }
    else {
      resolved.estop_soft = []
    }

    if (msg.estop_hard !== undefined) {
      resolved.estop_hard = msg.estop_hard;
    }
    else {
      resolved.estop_hard = []
    }

    if (msg.overheat !== undefined) {
      resolved.overheat = msg.overheat;
    }
    else {
      resolved.overheat = []
    }

    if (msg.overvoltage !== undefined) {
      resolved.overvoltage = msg.overvoltage;
    }
    else {
      resolved.overvoltage = []
    }

    if (msg.undervoltage !== undefined) {
      resolved.undervoltage = msg.undervoltage;
    }
    else {
      resolved.undervoltage = []
    }

    if (msg.short_detect !== undefined) {
      resolved.short_detect = msg.short_detect;
    }
    else {
      resolved.short_detect = []
    }

    if (msg.stall !== undefined) {
      resolved.stall = msg.stall;
    }
    else {
      resolved.stall = []
    }

    if (msg.amplimit !== undefined) {
      resolved.amplimit = msg.amplimit;
    }
    else {
      resolved.amplimit = []
    }

    if (msg.safetymotor !== undefined) {
      resolved.safetymotor = msg.safetymotor;
    }
    else {
      resolved.safetymotor = []
    }

    if (msg.brake !== undefined) {
      resolved.brake = msg.brake;
    }
    else {
      resolved.brake = []
    }

    return resolved;
    }
};

module.exports = ControllersStatus;
