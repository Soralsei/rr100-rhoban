// Auto-generated. Do not edit!

// (in-package rr100_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class DiagnosticData {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.name = null;
      this.cmd = null;
      this.speed = null;
      this.current = null;
      this.errloop = null;
      this.stall = null;
      this.tension = null;
      this.temp = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('name')) {
        this.name = initObj.name
      }
      else {
        this.name = [];
      }
      if (initObj.hasOwnProperty('cmd')) {
        this.cmd = initObj.cmd
      }
      else {
        this.cmd = [];
      }
      if (initObj.hasOwnProperty('speed')) {
        this.speed = initObj.speed
      }
      else {
        this.speed = [];
      }
      if (initObj.hasOwnProperty('current')) {
        this.current = initObj.current
      }
      else {
        this.current = [];
      }
      if (initObj.hasOwnProperty('errloop')) {
        this.errloop = initObj.errloop
      }
      else {
        this.errloop = [];
      }
      if (initObj.hasOwnProperty('stall')) {
        this.stall = initObj.stall
      }
      else {
        this.stall = [];
      }
      if (initObj.hasOwnProperty('tension')) {
        this.tension = initObj.tension
      }
      else {
        this.tension = [];
      }
      if (initObj.hasOwnProperty('temp')) {
        this.temp = initObj.temp
      }
      else {
        this.temp = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type DiagnosticData
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [name]
    bufferOffset = _arraySerializer.string(obj.name, buffer, bufferOffset, null);
    // Serialize message field [cmd]
    bufferOffset = _arraySerializer.float32(obj.cmd, buffer, bufferOffset, null);
    // Serialize message field [speed]
    bufferOffset = _arraySerializer.float32(obj.speed, buffer, bufferOffset, null);
    // Serialize message field [current]
    bufferOffset = _arraySerializer.float32(obj.current, buffer, bufferOffset, null);
    // Serialize message field [errloop]
    bufferOffset = _arraySerializer.float32(obj.errloop, buffer, bufferOffset, null);
    // Serialize message field [stall]
    bufferOffset = _arraySerializer.bool(obj.stall, buffer, bufferOffset, null);
    // Serialize message field [tension]
    bufferOffset = _arraySerializer.float32(obj.tension, buffer, bufferOffset, null);
    // Serialize message field [temp]
    bufferOffset = _arraySerializer.float32(obj.temp, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type DiagnosticData
    let len;
    let data = new DiagnosticData(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [name]
    data.name = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [cmd]
    data.cmd = _arrayDeserializer.float32(buffer, bufferOffset, null)
    // Deserialize message field [speed]
    data.speed = _arrayDeserializer.float32(buffer, bufferOffset, null)
    // Deserialize message field [current]
    data.current = _arrayDeserializer.float32(buffer, bufferOffset, null)
    // Deserialize message field [errloop]
    data.errloop = _arrayDeserializer.float32(buffer, bufferOffset, null)
    // Deserialize message field [stall]
    data.stall = _arrayDeserializer.bool(buffer, bufferOffset, null)
    // Deserialize message field [tension]
    data.tension = _arrayDeserializer.float32(buffer, bufferOffset, null)
    // Deserialize message field [temp]
    data.temp = _arrayDeserializer.float32(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    object.name.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    length += 4 * object.cmd.length;
    length += 4 * object.speed.length;
    length += 4 * object.current.length;
    length += 4 * object.errloop.length;
    length += object.stall.length;
    length += 4 * object.tension.length;
    length += 4 * object.temp.length;
    return length + 32;
  }

  static datatype() {
    // Returns string type for a message object
    return 'rr100_msgs/DiagnosticData';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'b876060a83a8a930a6f821b4ea6bc545';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # This is a message that holds different data from the controller and the PC 
    
    Header header
    
    string[] name
    float32[] cmd
    float32[] speed
    float32[] current
    float32[] errloop
    bool[] stall
    float32[] tension
    float32[] temp
    
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new DiagnosticData(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.name !== undefined) {
      resolved.name = msg.name;
    }
    else {
      resolved.name = []
    }

    if (msg.cmd !== undefined) {
      resolved.cmd = msg.cmd;
    }
    else {
      resolved.cmd = []
    }

    if (msg.speed !== undefined) {
      resolved.speed = msg.speed;
    }
    else {
      resolved.speed = []
    }

    if (msg.current !== undefined) {
      resolved.current = msg.current;
    }
    else {
      resolved.current = []
    }

    if (msg.errloop !== undefined) {
      resolved.errloop = msg.errloop;
    }
    else {
      resolved.errloop = []
    }

    if (msg.stall !== undefined) {
      resolved.stall = msg.stall;
    }
    else {
      resolved.stall = []
    }

    if (msg.tension !== undefined) {
      resolved.tension = msg.tension;
    }
    else {
      resolved.tension = []
    }

    if (msg.temp !== undefined) {
      resolved.temp = msg.temp;
    }
    else {
      resolved.temp = []
    }

    return resolved;
    }
};

module.exports = DiagnosticData;
