// Auto-generated. Do not edit!

// (in-package rr100_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class SendCmdRoboteqRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.serialport = null;
      this.baudrate = null;
      this.cmd = null;
    }
    else {
      if (initObj.hasOwnProperty('serialport')) {
        this.serialport = initObj.serialport
      }
      else {
        this.serialport = '';
      }
      if (initObj.hasOwnProperty('baudrate')) {
        this.baudrate = initObj.baudrate
      }
      else {
        this.baudrate = 0;
      }
      if (initObj.hasOwnProperty('cmd')) {
        this.cmd = initObj.cmd
      }
      else {
        this.cmd = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SendCmdRoboteqRequest
    // Serialize message field [serialport]
    bufferOffset = _serializer.string(obj.serialport, buffer, bufferOffset);
    // Serialize message field [baudrate]
    bufferOffset = _serializer.int64(obj.baudrate, buffer, bufferOffset);
    // Serialize message field [cmd]
    bufferOffset = _serializer.string(obj.cmd, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SendCmdRoboteqRequest
    let len;
    let data = new SendCmdRoboteqRequest(null);
    // Deserialize message field [serialport]
    data.serialport = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [baudrate]
    data.baudrate = _deserializer.int64(buffer, bufferOffset);
    // Deserialize message field [cmd]
    data.cmd = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.serialport);
    length += _getByteLength(object.cmd);
    return length + 16;
  }

  static datatype() {
    // Returns string type for a service object
    return 'rr100_msgs/SendCmdRoboteqRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'b3816ecbe942e069fb0ca58faf16fc44';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string serialport   # 
    int64 baudrate      # 
    string cmd          # 
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SendCmdRoboteqRequest(null);
    if (msg.serialport !== undefined) {
      resolved.serialport = msg.serialport;
    }
    else {
      resolved.serialport = ''
    }

    if (msg.baudrate !== undefined) {
      resolved.baudrate = msg.baudrate;
    }
    else {
      resolved.baudrate = 0
    }

    if (msg.cmd !== undefined) {
      resolved.cmd = msg.cmd;
    }
    else {
      resolved.cmd = ''
    }

    return resolved;
    }
};

class SendCmdRoboteqResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.success = null;
      this.message = null;
    }
    else {
      if (initObj.hasOwnProperty('success')) {
        this.success = initObj.success
      }
      else {
        this.success = false;
      }
      if (initObj.hasOwnProperty('message')) {
        this.message = initObj.message
      }
      else {
        this.message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SendCmdRoboteqResponse
    // Serialize message field [success]
    bufferOffset = _serializer.bool(obj.success, buffer, bufferOffset);
    // Serialize message field [message]
    bufferOffset = _serializer.string(obj.message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SendCmdRoboteqResponse
    let len;
    let data = new SendCmdRoboteqResponse(null);
    // Deserialize message field [success]
    data.success = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [message]
    data.message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.message);
    return length + 5;
  }

  static datatype() {
    // Returns string type for a service object
    return 'rr100_msgs/SendCmdRoboteqResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '937c9679a518e3a18d831e57125ea522';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool success        #
    string message      #
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SendCmdRoboteqResponse(null);
    if (msg.success !== undefined) {
      resolved.success = msg.success;
    }
    else {
      resolved.success = false
    }

    if (msg.message !== undefined) {
      resolved.message = msg.message;
    }
    else {
      resolved.message = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: SendCmdRoboteqRequest,
  Response: SendCmdRoboteqResponse,
  md5sum() { return 'b8798f1c9933425d372d37ea6c803230'; },
  datatype() { return 'rr100_msgs/SendCmdRoboteq'; }
};
