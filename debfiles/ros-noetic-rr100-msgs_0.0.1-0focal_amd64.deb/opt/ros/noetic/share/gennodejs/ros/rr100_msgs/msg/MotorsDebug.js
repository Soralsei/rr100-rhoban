// Auto-generated. Do not edit!

// (in-package rr100_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class MotorsDebug {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.name = null;
      this.command = null;
      this.speed = null;
      this.ampere = null;
      this.loop_err = null;
      this.temp = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('name')) {
        this.name = initObj.name
      }
      else {
        this.name = [];
      }
      if (initObj.hasOwnProperty('command')) {
        this.command = initObj.command
      }
      else {
        this.command = [];
      }
      if (initObj.hasOwnProperty('speed')) {
        this.speed = initObj.speed
      }
      else {
        this.speed = [];
      }
      if (initObj.hasOwnProperty('ampere')) {
        this.ampere = initObj.ampere
      }
      else {
        this.ampere = [];
      }
      if (initObj.hasOwnProperty('loop_err')) {
        this.loop_err = initObj.loop_err
      }
      else {
        this.loop_err = [];
      }
      if (initObj.hasOwnProperty('temp')) {
        this.temp = initObj.temp
      }
      else {
        this.temp = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type MotorsDebug
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [name]
    bufferOffset = _arraySerializer.string(obj.name, buffer, bufferOffset, null);
    // Serialize message field [command]
    bufferOffset = _arraySerializer.float64(obj.command, buffer, bufferOffset, null);
    // Serialize message field [speed]
    bufferOffset = _arraySerializer.float64(obj.speed, buffer, bufferOffset, null);
    // Serialize message field [ampere]
    bufferOffset = _arraySerializer.float64(obj.ampere, buffer, bufferOffset, null);
    // Serialize message field [loop_err]
    bufferOffset = _arraySerializer.float64(obj.loop_err, buffer, bufferOffset, null);
    // Serialize message field [temp]
    bufferOffset = _arraySerializer.float64(obj.temp, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type MotorsDebug
    let len;
    let data = new MotorsDebug(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [name]
    data.name = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [command]
    data.command = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [speed]
    data.speed = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [ampere]
    data.ampere = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [loop_err]
    data.loop_err = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [temp]
    data.temp = _arrayDeserializer.float64(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    object.name.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    length += 8 * object.command.length;
    length += 8 * object.speed.length;
    length += 8 * object.ampere.length;
    length += 8 * object.loop_err.length;
    length += 8 * object.temp.length;
    return length + 24;
  }

  static datatype() {
    // Returns string type for a message object
    return 'rr100_msgs/MotorsDebug';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '8847af5c1bb6400de64329fa619d49c8';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # This is a message that holds cmd, loop err and and speed data from each motor of the base for debug ploting.
    
    Header header
    
    string[] name
    float64[] command
    float64[] speed
    float64[] ampere
    float64[] loop_err
    float64[] temp
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new MotorsDebug(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.name !== undefined) {
      resolved.name = msg.name;
    }
    else {
      resolved.name = []
    }

    if (msg.command !== undefined) {
      resolved.command = msg.command;
    }
    else {
      resolved.command = []
    }

    if (msg.speed !== undefined) {
      resolved.speed = msg.speed;
    }
    else {
      resolved.speed = []
    }

    if (msg.ampere !== undefined) {
      resolved.ampere = msg.ampere;
    }
    else {
      resolved.ampere = []
    }

    if (msg.loop_err !== undefined) {
      resolved.loop_err = msg.loop_err;
    }
    else {
      resolved.loop_err = []
    }

    if (msg.temp !== undefined) {
      resolved.temp = msg.temp;
    }
    else {
      resolved.temp = []
    }

    return resolved;
    }
};

module.exports = MotorsDebug;
