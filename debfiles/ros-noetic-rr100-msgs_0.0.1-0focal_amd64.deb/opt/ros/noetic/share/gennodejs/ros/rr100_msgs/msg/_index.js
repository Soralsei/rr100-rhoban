
"use strict";

let ControllersStatus = require('./ControllersStatus.js');
let MotorsDebug = require('./MotorsDebug.js');
let DiagnosticData = require('./DiagnosticData.js');
let DoDockingFeedback = require('./DoDockingFeedback.js');
let DoTrajResult = require('./DoTrajResult.js');
let DoDockingAction = require('./DoDockingAction.js');
let DoDockingActionFeedback = require('./DoDockingActionFeedback.js');
let DoTrajAction = require('./DoTrajAction.js');
let DoTrajActionGoal = require('./DoTrajActionGoal.js');
let DoDockingActionResult = require('./DoDockingActionResult.js');
let DoTrajFeedback = require('./DoTrajFeedback.js');
let DoDockingActionGoal = require('./DoDockingActionGoal.js');
let DoDockingResult = require('./DoDockingResult.js');
let DoTrajActionResult = require('./DoTrajActionResult.js');
let DoTrajGoal = require('./DoTrajGoal.js');
let DoTrajActionFeedback = require('./DoTrajActionFeedback.js');
let DoDockingGoal = require('./DoDockingGoal.js');

module.exports = {
  ControllersStatus: ControllersStatus,
  MotorsDebug: MotorsDebug,
  DiagnosticData: DiagnosticData,
  DoDockingFeedback: DoDockingFeedback,
  DoTrajResult: DoTrajResult,
  DoDockingAction: DoDockingAction,
  DoDockingActionFeedback: DoDockingActionFeedback,
  DoTrajAction: DoTrajAction,
  DoTrajActionGoal: DoTrajActionGoal,
  DoDockingActionResult: DoDockingActionResult,
  DoTrajFeedback: DoTrajFeedback,
  DoDockingActionGoal: DoDockingActionGoal,
  DoDockingResult: DoDockingResult,
  DoTrajActionResult: DoTrajActionResult,
  DoTrajGoal: DoTrajGoal,
  DoTrajActionFeedback: DoTrajActionFeedback,
  DoDockingGoal: DoDockingGoal,
};
