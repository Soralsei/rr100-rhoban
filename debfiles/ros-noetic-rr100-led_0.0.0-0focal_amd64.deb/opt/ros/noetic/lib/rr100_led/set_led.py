#!/usr/bin/env python3
# coding: utf-8
import actionlib 
import roslib
import rospkg
import rospy
from geometry_msgs.msg import Twist
from std_msgs.msg import ColorRGBA, Bool

class SetLed():
    def __init__(self):
        rospack = rospkg.RosPack()
        package_path = rospack.get_path('rr100_led')
        # ROS param

        #topic published
        self.ros_pub_color_top_ = rospy.Publisher("/set_top_led", ColorRGBA, queue_size = 10)
        self.ros_pub_color_mid_ = rospy.Publisher("/set_middle_led", ColorRGBA, queue_size = 10)
        self.ros_pub_color_bot_ = rospy.Publisher("/set_bottom_led", ColorRGBA, queue_size = 10)
        self.ros_pub_rr100_docked = rospy.Publisher("/home/docked", Bool, queue_size = 1, latch = True)

        msg_docked = Bool()
        msg_docked.data = False
        self.ros_pub_rr100_docked.publish(msg_docked)

        #topic read
        self.ros_sub_middle_led_  = rospy.Subscriber("/set_led/state", ColorRGBA, self.cb_color_middle)
        self.ros_sub_top_led_  = rospy.Subscriber("/set_led/top", ColorRGBA, self.cb_color_top)
        self.ros_sub_battery_led_ = rospy.Subscriber("/set_led/battery", ColorRGBA, self.cb_color_battery)
        self.ros_sub_home_docked_ = rospy.Subscriber("/rr100/docked", Bool, self.cb_home_docked)
        self.color_top_ = ColorRGBA(0, 0, 0, 0)
        self.color_middle_ = ColorRGBA(255, 80, 0, 0)
        self.color_bottom_ = ColorRGBA(0, 0, 0, 0)

        #variable
        self.is_backward_ = False

    def cb_home_docked(self, msg):
        self.ros_pub_rr100_docked.publish(msg)

    def cb_color_middle(self, color):
        self.color_middle_ = color

    def cb_color_battery(self, color):
        self.color_bottom_ = color

    def cb_color_top(self, color):
        self.color_top_ = color

    def loop(self):
        time = rospy.Rate(5)
        while not rospy.is_shutdown():
            #top led backward case
            self.ros_pub_color_top_.publish(self.color_top_)    
            #middle led 
            self.ros_pub_color_mid_.publish(self.color_middle_)
            #bottom led 
            self.ros_pub_color_bot_.publish(self.color_bottom_)

            time.sleep()

if __name__ == '__main__':
    rospy.init_node('set_top_led', anonymous=True)
    rospy.loginfo("Set_top_led node starting")

    try :
        nh = SetLed()
        nh.loop()
    except rospy.ROSInterruptException:
        pass
