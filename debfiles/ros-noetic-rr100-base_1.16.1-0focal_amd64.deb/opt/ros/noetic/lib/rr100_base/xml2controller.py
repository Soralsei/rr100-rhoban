#!/usr/bin/env python2
# -*- coding: utf-8 -*-


#USAGE
# xml2controller.py [-h] xml_file port
#   xml_file is the path to the file to get parameters
#   port is the serial port

import sys
import re
from datetime import datetime
import serial
import argparse
from time import sleep
import xml.etree.ElementTree as ET


#Open a serial connection 
# the default port is /dev/ttyACM0 
# or can be specified in the command line 
def openSerial(args):
    portOpened = False
    while (not portOpened):
        try:
            ser = serial.Serial(args.port, baudrate=115200, timeout=0.5)
            portOpened = True
        except serial.SerialException:
            print("Serial - Failed to open Serial connection")
            sleep(1)
        except serial.SerialTimeoutException:
            print("Serial - Failed to open Serial : timed out")
            sleep(1) 
    print(ser.name)
    return ser

#Iterate over all Item node
def getItem(node, ser):
    for item in node.iter("Item"):
        command, index, typeArg, value = getCommand(item)
        if typeArg == 'String' :
            value = getString(value)
        sendCommand(ser, command, index, value)
    

#Get parameters Command, Index, ArgumentType and Value of the item node 
def getCommand(item):
    command = item.attrib.get("Command")
    index = item.attrib.get("Index")
    typeArg = item.find("ArgumentType").text
    value = item.find("Value").text
    return (command, index, typeArg, value)

#Write the command to the serial port
def sendCommand(ser, command, index, value) :
    ser.write('^'+command+' '+index+' '+value+'\r')
    ans = ser.readline()
    index_plus = ans.find('+')
    if index_plus == -1 :
        len_ans = len(ans)
        if len_ans >= 2 :
            print("Problem with command "+command+" channel "+index+". Resp : "+ans[len_ans-2:len_ans-1])
        else :
            print("Problem with command "+command+" channel "+index+". Resp : "+ans)


#Change the value of the String to be in the good format
def getString(value) :
    ret = ""
    if value is not None:
        ret = "\""+value+"\""
    return ret




if __name__ == '__main__':
    #Define parser for command-line
    parser = argparse.ArgumentParser(description='Get command from a xml file and set the controller')

    parser.add_argument('xml_file', metavar='xml_file', help='path of xml file')
    parser.add_argument('port', metavar='port', help='serial port')

    args = parser.parse_args()

    #Parsing xml from file given by command-line
    tree = ET.parse(args.xml_file)
    root = tree.getroot()

    firmware = root.find("Firmware")
    controlTree = root.find("ControlTree")
    powerTree = root.find("PowerTree")

    #Get date firmware
    num_firm = firmware.text 
    date_xml = re.search(r'\d{2}/\d{2}/\d{4}', num_firm)
    if date_xml != None : 
        date_xml = datetime.strptime(date_xml.group(), '%m/%d/%Y').date()
    else :
        txt = raw_input("Problem to access the xml firmware version. Do you want to continue ? [y/n]")
        if (txt == "no") | (txt == "n") :
            sys.exit("Impossible access to xml firmware version")
        elif (txt != "yes") & (txt != "y") :
            sys.exit("Answer not valid")

    ser = openSerial(args)

    #Get date firmware controller
    ser.write('?FID\r')
    ans = ser.readline()
    date_contro = re.search(r'\d{2}/\d{2}/\d{4}', ans)
    if date_contro != None : 
        date_contro = datetime.strptime(date_contro.group(), '%m/%d/%Y').date()
    else :
        txt = raw_input("Problem to access the controller firmware version. Do you want to continue ? [y/n]")
        if (txt == "no") | (txt == "n") :
            sys.exit("Impossible access to controller firmware version")
        elif (txt != "yes") & (txt != "y") :
            sys.exit("Answer not valid")

    #Verify version firmwares
    if date_xml < date_contro :
        txt = raw_input("The firmware version of the xml is older than the controller version. Do you want to continue ? [y/n]")
        if (txt == "no") | (txt == "n") :
            sys.exit("Firmware version too old")
        elif (txt != "yes") & (txt != "y") :
            sys.exit("Answer not valid")

    #Iterate over the item node
    if controlTree != None :
        getItem(controlTree, ser)
    if powerTree != None :
        getItem(powerTree, ser)
    
    #Close serial connection
    ser.close()
    print("Port closed")


