#!/usr/bin/env python3

"""
Script read the diagnostic low level easier
"""

import rospy
import time
from std_msgs.msg import Float32MultiArray, UInt8MultiArray


class Reader:
	def __init__(self):
    		self.sub = rospy.Subscriber(
			"/diagnostics_lowlevel", Float32MultiArray, self.cb_rpy, queue_size=1)
		self.sub = rospy.Subscriber(
			"/diagnostics_lowlevel", UInt8MultiArray, self.cb_rpy, queue_size=1)
		self.start = time.time()


	def cb_rpy(self,msg):
		data = msg.data
		elapsedTime = (time.time()-self.start)
		print "\n------------- elapsed time \t", elapsedTime , "------------- (freq = ", 1/elapsedTime, ")"
		print ("speed =\t M1 = {0:04.2f} \tM2 = {1:04.2f} \tM3 = {2:04.2f} \tM4 = {3:04.2f} \tM0 pos= {4:04.2f}".format(data[8],data[9],data[10],data[11],data[12]))
		print ("cmd =\t M1 = {0:04.2f} \tM2 = {1:04.2f} \tM3 = {2:04.2f} \tM4 = {3:04.2f} \tSteer = {4:04.2f}".format(data[0],data[1],data[2],data[3],data[4]))
		print ("amp =\t M1 = {0:04.2f} \tM2 = {1:04.2f} \tM3 = {2:04.2f} \tM4 = {3:04.2f} \tSteer = {4:04.2f} \tbattery = {5:04.2f}".format(data[16],data[17],data[18],data[19],data[20],data[21]))
		print ("pwr =\t M1 = {0:04.2f} \tM2 = {1:04.2f} \tM3 = {2:04.2f} \tM4 = {3:04.2f} \tSteer = {4:04.2f}".format(data[56],data[57],data[58],data[59],data[60]))
		print ("A_lim =\t M1 = {0:04.2f} \tM2 = {1:04.2f} \tM3 = {2:04.2f} \tM4 = {3:04.2f} \tSteer = {4:04.2f}".format(data[64],data[65],data[66],data[67],data[68]))
		print ("temp =\t R0 = {0:04.2f} \tR1 = {1:04.2f} \tR2 = {2:04.2f} \tSonde 1 = {3:04.2f} \tSonde 2= {4:04.2f}".format(data[48],data[49],data[50],data[51],data[52]))
		
		self.start = time.time()

if __name__ == '__main__':

	rospy.init_node('diagnosticsLowLevelReader')
	time.sleep(1)

	node = Reader()
	
	rospy.spin()
