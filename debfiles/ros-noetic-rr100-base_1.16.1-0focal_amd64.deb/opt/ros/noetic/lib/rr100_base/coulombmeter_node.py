#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rospy

if __name__ == '__main__':
    rospy.init_node('coulombmeter', anonymous=True, log_level=rospy.DEBUG)

    coulombmeter_comm_type = rospy.get_param("/coulombmeter_node/type")
    rospy.logwarn("Coulombmeter_node/__init__ - using type: " + str(coulombmeter_comm_type))

    if "CC" in coulombmeter_comm_type: # CC75 or CC150 or CC500
        from rr100_base.serial_coulombmeter import SerialCoulombmeter
        SerialCoulombmeter()

    elif coulombmeter_comm_type == "can":
        from rr100_base.can_coulombmeter import CanCoulombmeter
        CanCoulombmeter()

    else:
        rospy.logwarn("Coulombmeter communication type not set")

    rospy.spin()
