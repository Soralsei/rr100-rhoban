#!/usr/bin/env python2
# -*- coding: utf-8 -*-


#USAGE
# controller2xml.py [-h] [--output OUTPUT_FILE] model_file port
#   model_file is the path to the file to get command
#   port is the serial port
#   output_file is the path to the file to save xml

import serial
import argparse
from time import sleep
import xml.etree.ElementTree as ET

#Open a serial connection 
# the default port is /dev/ttyACM0 
# or can be specified in the command line 
def openSerial(args):
    portOpened = False
    while (not portOpened):
        try:
            ser = serial.Serial(args.port, baudrate=115200, timeout=0.5)
            portOpened = True
        except serial.SerialException:
            print("Serial - Failed to open Serial connection")
            sleep(1)
        except serial.SerialTimeoutException:
            print("Serial - Failed to open Serial : timed out")
            sleep(1) 
    print(ser.name)
    return ser

#Iterate over all Item node
#Get Command and index parameters
#Send read command to the controller
def getItem(node, ser):
    item_to_remove = []
    for item in node.iter("Item"):
        command = item.attrib.get("Command")
        index = item.attrib.get("Index")
        ser.write('~'+command+' '+index+'\r')
        ans = ser.readline()
        index_eq = ans.find('=')
        if index_eq != -1 :
            # = sign found
            index_r = ans.find('\r', index_eq)
            value = ans[index_eq+1:index_r]
            #Change the value with the one give by controller
            item.find("Value").text = str(value)
        else :
            len_ans = len(ans)
            if len_ans >= 2 :
                print("Problem with command "+command+" channel "+index+". Resp : "+ans[len_ans-2:len_ans-1])
            else :
                print("Problem with command "+command+" channel "+index+". Resp : "+ans)
            item_to_remove.append(item)
    #Remove all the node not defined
    for del_item in item_to_remove :
        node.remove(del_item)
    

if __name__ == '__main__':
    #Define parser for command-line
    parser = argparse.ArgumentParser(description='Get controller command to xml file')

    parser.add_argument('xml_empty_file', metavar='model_file', help='path of the xml file from which the commands are get')
    parser.add_argument('port', metavar='port', help='serial port')
    parser.add_argument('--output', dest='output_file', default="output.cpr", help='name of output file (default: output.cpr)')
        
    args = parser.parse_args()

    #Parsing xml from file given by command-line
    tree = ET.parse(args.xml_empty_file)
    root = tree.getroot()

    firmware = root.find("Firmware")
    controlTree = root.find("ControlTree")
    powerTree = root.find("PowerTree")

    ser = openSerial(args)
    
    #Change firmware version 
    ser.write('?FID\r')
    ans = ser.readline()
    index_eq = ans.find('=')
    if index_eq != -1 :
        # = sign found
        index_r = ans.find('\r', index_eq)
        value = ans[index_eq+1:index_r]
        #Change the value with the one give by controller
        firmware.text = str(value)
    else :
        txt = raw_input("Problem to access the controller firmware version. Do you want to continue ? [y/n]")
        if (txt == "no") | (txt == "n") :
            sys.exit("Impossible access to controller firmware version")
        elif (txt != "yes") & (txt != "y") :
            sys.exit("Answer not valid")

    #Iterate over the item node
    if controlTree != None :
        getItem(controlTree, ser)
    if powerTree != None :
        getItem(powerTree, ser)
    ser.close()
    print("Port closed")

    #Add attribute to the root
    root.set('xmlns:xsd', 'http://www.w3.org/2001/XMLSchema')
    root.set('xmlns:xsi', 'http://www.w3.org/2001/XMLSchema-instance')
    tree.write(args.output_file, xml_declaration=True,encoding='utf-8',
            method="xml")


