#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import collections
import datetime
import threading
from time import sleep

import rospy
import can
from diagnostic_msgs.msg import DiagnosticArray, DiagnosticStatus, KeyValue
from std_msgs.msg import (Bool, ColorRGBA, Float32MultiArray,
                          MultiArrayDimension)

class CanCoulombmeter():
    def __del__(self):
        self.cleanup()

    def cleanup(self):
        self._stop_reader()  # closes serial port
        self.main_loop_timer.shutdown()  # kill the timers 

    def __init__(self):
        rospy.on_shutdown(self.cleanup)
        self.portOpened = False
        self.successiveErrCount = 0
        self.bad_data_count = 0
        self.offset = None

        self.debug = rospy.get_param("/rr100_debug", default=False)
        

        # ros variables
        # battery message
        self.battery_msg = Float32MultiArray()
        self.init_multi_array("percentage(%), volt(V), current(A), power(W), SOH(%), charging(bool), charge_complete(bool)", 7)
        self.ros_pub_battery_data = rospy.Publisher("/coulombmeter/battery_data", Float32MultiArray, queue_size=1, latch=True)
        self.lastData =self.battery_msg.data[:] # already init in init_multi_array

        # Mutex battery_msg
        self.mutex_battery_msg = threading.Lock()

        # battery led publisher
        self.ros_pub_color_battery_ = rospy.Publisher(
            "/set_led/battery",  ColorRGBA, queue_size=1, latch=True)

        # disgnostics messages
        self.pub_diagnostics = rospy.Publisher(
            '/diagnostics', DiagnosticArray, queue_size=1, latch=True)

        self.charging_buffer = collections.deque(maxlen=15)

        # battery alert
        self._low_battery_alert = False
        self._low_battery_alert_previous = True
        self.ros_pub_low_battery_alert = rospy.Publisher("/coulombmeter/low_battery_alert", Bool, queue_size=1, latch=True)

        # start Reader timer        
        self.receiver_thread = threading.Thread(target=self.reader, name='rx')
        self._start_reader()

        # start Main timer
        self.loop_rate_main = rospy.Duration(1)  # 1s
        self.main_loop_timer = rospy.Timer(self.loop_rate_main, self.main_loop)
        rospy.logwarn("CanCoulombmeter/__init__ - thread started - main_loop ready to publish")

    def init_multi_array(self, label, size):
        self.battery_msg.layout.dim.append(MultiArrayDimension())
        self.battery_msg.layout.dim[0].size = size
        self.battery_msg.layout.dim[0].stride = 1
        self.battery_msg.layout.dim[0].label = label
        self.battery_msg.data = [0]*size

    def reader(self):
        try:
            # connect can bus
            while (not self.portOpened):
                try:
                    self.bus = can.interface.Bus(bustype='socketcan', channel='slcan0', bitrate=1000000) #open CAN BUS
                    self.portOpened = True
                except OSError:
                    rospy.logerr("CanCoulombmeter/reader - Failed to connect CAN bus")
                    sleep(1) 

            while(self._reader_alive):
                msg = self.bus.recv()
                if msg is not None and msg.arbitration_id == 1: 
                    data = msg.data
                    self.offset = 0
                    with self.mutex_battery_msg: #block the topic message to fill it
                        self.battery_msg.data = [] #empty it to init
                        self.createBatteryMessage(data) #decode and fill                    
                elif msg is None: #not recieving data 
                    if self.debug:
                        rospy.logwarn("CanCoulombmeter/reader -  no data yet, waiting for new data")
                    self.incrementSuccessiveErrCount()
        except Exception as e:
            if self.debug:
                rospy.logwarn("CanCoulombmeter/reader - Error is : " + str(e))
            self.successiveErrCount = self.successiveErrCount + 1
            sleep(1)
            if(self.successiveErrCount > 30):
                rospy.logerr("CanCoulombmeter/reader - killing the node for respawn")
                rospy.signal_shutdown("Shutting CanCoulombmeter down")


    def _start_reader(self):
        """Start reader thread"""
        self._reader_alive = True
        self.receiver_thread.daemon = True
        self.receiver_thread.start()
        rospy.loginfo("CanCoulombmeter/_start_reader - thread started - ready to read")

    def incrementSuccessiveErrCount (self):
        #if we recieve bad data, allow to copy the last good data 10 times before sending ZEROES
        if self.bad_data_count >=20 : 
            if self.bad_data_count%10 == 0 :#drop a warning log (just once every 10s)
                rospy.logwarn("CanCoulombmeter/incrementSuccessiveErrCount - no data or erroneous data recieved. succesive bad_data_count >= 20 : " + str(self.bad_data_count))  
            self.battery_msg.data = [0.0] * self.battery_msg.layout.dim[0].size #error count exceeded > send 0s
            self.bad_data_count = self.bad_data_count + 1
        else : 
            #rospy.logwarn("CanCoulombmeter/incrementSuccessiveErrCount - no data or erroneous data recieved. succesive bad_data_count : " + str(self.bad_data_count))  
            self.battery_msg.data = self.lastData[:]
            self.bad_data_count = self.bad_data_count + 1

    def twos_comp(self, val, bits):
        """compute the 2's complement of int value val"""
        if (val & (1 << (bits - 1))) != 0: # if sign bit is set e.g., 8bit: 128-255
            val = val - (1 << bits)    	# compute negative value
        return val                     	# return positive value as is

    def append_hex(self, a, b):
        """concatane two hexa number"""
        return (a << 8) | b

    def createBatteryMessage(self, data):
        try:
            # percentage
            percentage = self.append_hex(data[5], data[4]) *0.01
            self.battery_msg.data.append(round(percentage, 2))
            if percentage < 20:
                self._low_battery_alert = True
            else:
                self._low_battery_alert = False
            # print ("percentage = " + str(('%.2f'%(percentage))) + "%")

            # voltage
            voltage = self.append_hex(data[1], data[0])          #int(format(ord(line[2+self.offset]), "x") + format(ord(line[1+self.offset]), "x"), 16)
            self.battery_msg.data.append(round((voltage*0.01), 2))
            # print ("voltage = " + str('%.2f'%(voltage*0.01)) + "V")

            # current
            current = self.append_hex(data[3], data[2])
            current = self.twos_comp(current,16)
            #int(format(ord(line[10+self.offset]), "x") + format(ord(line[9+self.offset]), "x") + format(ord(line[8+self.offset]), "x") + format(ord(line[7+self.offset]), "x"), 16)
            current_float = current*0.01
            self.battery_msg.data.append(round(current_float, 2))
            # print ("current = " + str('%.2f'%(current*0.001)) + "A")

            # power
            power = current_float * (voltage*0.01)
            self.battery_msg.data.append(power)
            # print ("power = " + str('%.2f'%(power)) + "W")

            # SOH (state of Health) presents the lifetime of a battery. It reflects the general condition of a battery compared to the initial condition. Ideally, the SOH is 100% for a new battery.
            soh = self.append_hex(data[7], data[6]) *0.01
            self.battery_msg.data.append(round(soh, 2))

            # Charging state
            if current_float > 0:
                charging = 1
            else:
                charging = 0
            self.battery_msg.data.append(charging)

            # Charge complete
            if percentage == 100.0 and current_float < 10:
                charge_complete = 1
            else:
                charge_complete = 0
            self.battery_msg.data.append(charge_complete) 
            
            #remember last data up to 10 times successively
            self.lastData = self.battery_msg.data[:]
            self.successiveErrCount = 0
            if self.bad_data_count >= 20 :
                rospy.logwarn("CanCoulombmeter/createBatteryMessage - data came back -> bad_data_count = 0 ") 
            self.bad_data_count = 0
            if self.debug:
                rospy.logdebug("CanCoulombmeter/createBatteryMessage - battery_msg : " + str(self.battery_msg.data))
                rospy.logdebug("CanCoulombmeter/createBatteryMessage - lastData : " + str(self.lastData))
        except Exception as e:
            rospy.logwarn("CanCoulombmeter/createBatteryMessage - Error is : " + str(e))

    def publishBatteryLED(self):
        color = None
        # rospy.logwarn("publishBatteryLED - self.battery_msg.data is: " + str(self.battery_msg.data))
        if len(self.battery_msg.data) > 0:
            # convert the percent [0-100] to [0-255]
            p = self.battery_msg.data[0] * 2.55

            # handle the battery alert
            if(self._low_battery_alert):
                color = ColorRGBA(255.0 - p, p, 0, 500.0)
            # handles the normal case (degradé de couleur between red and green)
            elif(p > 0 and p <= 255):
                color = ColorRGBA(255.0 - p, p, 0, 0)
            # handles the no data case
            else:
                color = ColorRGBA(255.0, 128, 0, 1000)

        if (color != None):
            self.ros_pub_color_battery_.publish(color)
        else:
            rospy.logerr(
                "CanCoulombmeter/publishBatteryLED - msg battery data is empty.")
            color = ColorRGBA(255.0, 0.0, 0, 0)
            self.ros_pub_color_battery_.publish(color)

    def _stop_reader(self):
        self._reader_alive = False
        self.receiver_thread.join()
        rospy.loginfo("CanCoulombmeter/_stop_reader - thread halted - ready to terminate")
        self.bus.shutdown()

    def publishDiagnostics(self):
        with self.mutex_battery_msg:
            arr = DiagnosticArray()
            values = []
            values.append(            KeyValue("Percentage Left", str(self.battery_msg.data[0])))
            values.append(            KeyValue("Voltage",         str(self.battery_msg.data[1])))
            values.append(            KeyValue("Power",           str(self.battery_msg.data[2])))
            values.append(            KeyValue("Current",         str(self.battery_msg.data[3])))
            values.append(            KeyValue("State of Health", str(self.battery_msg.data[4])))
            values.append(            KeyValue("Charging",        str(self.battery_msg.data[5])))
            values.append(            KeyValue("Charge complete", str(self.battery_msg.data[6])))
            values.append(            KeyValue("Alert Battery",   str(self._low_battery_alert)))

            if(self.battery_msg.data[1] < 40 and self._low_battery_alert):
                arr.status = [DiagnosticStatus(level=DiagnosticStatus.ERROR, name="CanCoulombmeter", message="Error - Battery Critical", values=values)]
            elif(self._low_battery_alert):
                arr.status = [DiagnosticStatus(level=DiagnosticStatus.WARN, name="CanCoulombmeter", message="Warning - Low Battery", values=values)]
            else:
                arr.status = [DiagnosticStatus(level=DiagnosticStatus.OK, name="CanCoulombmeter", message="OK", values=values)]
            
            arr.header.stamp = rospy.Time.now()
            self.pub_diagnostics.publish(arr)

    def main_loop(self, timer):
        """
        Main loop that is threaded to publish the diagnostic feedback
        """
        try:
            if not rospy.is_shutdown():
                try:
                    if self.debug:
                        rospy.loginfo_throttle(5, "CanCoulombmeter/main_loop - feedback message is being built.")
                    # rospy.loginfo("CanCoulombmeter/main_loop - feedback message is being built.")

                    # publish battery data
                    with self.mutex_battery_msg:
                        if len(self.battery_msg.data) == self.battery_msg.layout.dim[0].size:
                            try:
                                self.ros_pub_battery_data.publish(self.battery_msg)
                                # publish alert battery if need be
                                if self._low_battery_alert != self._low_battery_alert_previous:
                                    self.ros_pub_low_battery_alert.publish(
                                        self._low_battery_alert)
                                    self._low_battery_alert_previous = self._low_battery_alert
                            except Exception as e:
                                rospy.logerr("CanCoulombmeter/main_loop/# publish battery data - Error is : " + str(e))

                            # publish Diagnostics
                            # try:
                            #     self.publishDiagnostics()
                            # except Exception as e:
                            #     rospy.logerr("CanCoulombmeter/main_loop/#publish Diagnostics - Error is : " + str(e))

                            # publish LED battery state
                            try:
                                self.publishBatteryLED()
                            except Exception as e:
                                rospy.logerr("CanCoulombmeter/main_loop/#publish LED battery state - Error is : " + str(e))                     
                        else:
                            rospy.logerr("CanCoulombmeter/main_loop - Bad len of data array ! - Len : " + str(len(self.battery_msg.data)))
                except Exception as e:
                    rospy.logerr("CanCoulombmeter/main_loop - Error is : " + str(e))
        except Exception as e:
            rospy.logwarn("CanCoulombmeter/main_loop - shutdown called. Error is : " + str(e))

