#!/usr/bin/env python
# -*- coding: utf-8 -*-
import collections
import datetime
import threading

import rospy
import serial
from diagnostic_msgs.msg import DiagnosticArray, DiagnosticStatus, KeyValue
from std_msgs.msg import (Bool, ColorRGBA, Float32MultiArray,
                          MultiArrayDimension)


class SerialCoulombmeter():
    def __del__(self):
        self.cleanup()

    def cleanup(self):
        self._stop_reader()  # closes serial port
        self.main_loop_timer.shutdown()  # kill the timers 

    def __init__(self):
        rospy.on_shutdown(self.cleanup)
        self.portOpened = False
        self.successiveErrCount = 0
        self.bad_data_count = 0
        self.offset = None

        self.debug = rospy.get_param("/rr100_debug", default=False)
        self.type = rospy.get_param("/coulombmeter_node/type", default="CC150")  # can be "CC75" or 150 or 500
        rospy.logwarn("Serial"+self.type +"/__init__ - using type: " + str(self.type))

        # ros variables
        # battery message
        self.battery_msg = Float32MultiArray()
        self.init_multi_array("percentage(%), volt(V), current(A), power(W), timeleft(s), charging(bool), charge_complete(bool)", 7)
        self.ros_pub_battery_data = rospy.Publisher("/coulombmeter/battery_data", Float32MultiArray, queue_size=1, latch=True)
        self.lastData =self.battery_msg.data[:] # already init in init_multi_array

        # Mutex battery_msg
        self.mutex_battery_msg = threading.Lock()

        # battery led publisher
        self.ros_pub_color_battery_ = rospy.Publisher(
            "/set_led/battery",  ColorRGBA, queue_size=1, latch=True)

        # disgnostics messages
        self.pub_diagnostics = rospy.Publisher(
            '/diagnostics', DiagnosticArray, queue_size=1, latch=True)

        self.charging_buffer = collections.deque(maxlen=15)

        # battery alert
        self._low_battery_alert = False
        self._low_battery_alert_previous = True
        self.ros_pub_low_battery_alert = rospy.Publisher("/coulombmeter/low_battery_alert", Bool, queue_size=1, latch=True)

        # start Reader timer        
        self._start_reader()

        # start Main timer
        self.loop_rate_main = rospy.Duration(1)  # 1s
        self.main_loop_timer = rospy.Timer(self.loop_rate_main, self.main_loop)
        rospy.logwarn("Serial"+self.type + "/__init__ - thread started - main_loop ready to publish")

    def init_multi_array(self, label, size):
        self.battery_msg.layout.dim.append(MultiArrayDimension())
        self.battery_msg.layout.dim[0].size = size
        self.battery_msg.layout.dim[0].stride = 1
        self.battery_msg.layout.dim[0].label = label
        self.battery_msg.data = [0]*size

    def reader(self):
        try:
            # open serial connection
            self._ser = None
            while (self._reader_alive and not self.portOpened and (not rospy.is_shutdown())):
                try:
                    self._ser = serial.Serial(
                        "/dev/coulomb", baudrate=19200, timeout=0.5)
                    self.portOpened = True
                except serial.SerialException:
                    rospy.logerr("Serial"+self.type +"/reader - Failed to open Serial connection")
                    rospy.sleep(1)
                except serial.SerialTimeoutException:
                    rospy.logerr("Serial"+self.type +"/reader - Failed to open Serial : timed out")
                    rospy.sleep(1)   
            line = ""
            data = []
            if self._ser is None:
                rospy.logerr("Serial"+self.type +"/reader - Failed to initialize Serial connection ! Aborting..")
                return

            while(self._reader_alive and (not rospy.is_shutdown() ) ):
                line=self._ser.read()
                if( len(line)>0): #read till filling buffer with 17 bytes
                    data.append(ord(line))
                elif len(data) == 17:
                    if self.debug:
                        rospy.logdebug("Serial"+self.type+"/reader -  processing data while waiting for new data: ") 
                        rospy.logdebug("Serial"+self.type+"/reader -  data: "+str(data))

                    #if CC75, throw the 1st byte at the en to match other versions (CC500, CC150)
                    if self.type == "CC75":
                        c = (data[1:])
                        c.append(data[0])
                        data = c[:]

                    #compute checksum
                    checksum = sum(data[0:-2]) & 0xff
                    if self.debug:
                        rospy.logdebug("Serial"+self.type+"/reader -  checksum : "+ str( sum(data[0:-2]) & 0xff ) )
                        rospy.logdebug("Serial"+self.type+"/reader -  last byte: "+str(data[-2]))
                    
                    #if checksums checkout, then the frame is valid and we can go ahead to decoding it
                    if checksum == data[-2] : 
                        self.offset = 0
                        with self.mutex_battery_msg: #block the topic message to fill it
                            self.battery_msg.data = [] #empty it to init
                            self.createBatteryMessage(data) #decode and fill
                    else : #the data are out of sync
                        rospy.logwarn("Serial"+self.type+"/reader -  Resync-ing Coulombmeter coms")
                        for i in range(20): #for a bit longer than a complete cycle ( 1 cycle = 1s = 17bytes + max 2 read timed out (0.5s) -> 19 reads )
                            line=self._ser.read() 
                            if( len(line)>0): #read till filling buffer with 17 bytes
                                data.append(ord(line)) #add the new byte to the end
                                data = data[1:] #pop the 1st byte
                            checksum = sum(data[0:-2]) & 0xff
                            if(checksum == data[-2]) :
                                break # we resync 
                    
                    #empty the data buffer for new reading
                    data = []
                    
                else: #not recieving data 
                    if self.debug:
                        rospy.logwarn("Serial"+self.type+"/reader -  no data yet, waiting for new data")
                    self.incrementSuccessiveErrCount()
                    data = []

        except serial.SerialException:
            if self.debug:
                rospy.logwarn("Serial" + self.type + "/reader - Failed to read data")
            self.successiveErrCount = self.successiveErrCount + 1
            rospy.sleep(1)
            if(self.successiveErrCount > 30):
                rospy.logerr("Serial" + self.type + "/reader - killing the node for respawn")
                rospy.signal_shutdown("Shutting Serial"+self.type+" down")

    def _start_reader(self):
        """Start reader thread"""
        self.receiver_thread = threading.Thread(target=self.reader, name='rx')            
        self._reader_alive = True
        self.receiver_thread.daemon = True
        self.receiver_thread.start()
        rospy.loginfo("Serial" + self.type + "/_start_reader - thread started - ready to read")

    def incrementSuccessiveErrCount (self):
        #if we recieve bad data, allow to copy the last good data 10 times before sending ZEROES
        if self.bad_data_count >=20 : 
            if self.bad_data_count%10 == 0 :#drop a warning log (just once every 10s)
                rospy.logwarn("Serial"+self.type+"/incrementSuccessiveErrCount - no data or erroneous data recieved. succesive bad_data_count >= 20 : " + str(self.bad_data_count))  
            self.battery_msg.data = [0.0] * self.battery_msg.layout.dim[0].size #error count exceeded > send 0s
            self.bad_data_count = self.bad_data_count + 1
        else : 
            #rospy.logwarn("Serial"+self.type+"/incrementSuccessiveErrCount - no data or erroneous data recieved. succesive bad_data_count : " + str(self.bad_data_count))  
            self.battery_msg.data = self.lastData[:]
            self.bad_data_count = self.bad_data_count + 1

    def createBatteryMessage(self, data_d):
        try:
            # percentage
            percentage = data_d[0+self.offset]
            self.battery_msg.data.append(round(percentage, 2))
            if percentage < 20:
                self._low_battery_alert = True
            else:
                self._low_battery_alert = False
            # print ("percentage = " + str(('%.2f'%(percentage))) + "%")

            # voltage
            voltage = ((data_d[2]<<8)+data_d[1])*0.01              #int(format(ord(line[2+self.offset]), "x") + format(ord(line[1+self.offset]), "x"), 16)
            self.battery_msg.data.append(round((voltage), 2))
            # print ("voltage = " + str('%.2f'%(voltage)) + "V")

            # current
            current = ((data_d[10]<<32)+(data_d[9]<<16)+(data_d[8]<<8)+data_d[7])*0.001
            #int(format(ord(line[10+self.offset]), "x") + format(ord(line[9+self.offset]), "x") + format(ord(line[8+self.offset]), "x") + format(ord(line[7+self.offset]), "x"), 16)
            current_float = current
            self.battery_msg.data.append(round(current_float, 3))
            # print ("current = " + str('%.2f'%(current)) + "A")

            # power
            power = current * voltage
            self.battery_msg.data.append(power)
            # print ("power = " + str('%.2f'%(power)) + "W")

            # time left
            timeleft = (data_d[14]<<32)+(data_d[13]<<16)+(data_d[12]<<8)+data_d[11]
            #int(format(ord(line[14+self.offset]), "x") + format(ord(line[13+self.offset]), "x") + format(ord(line[12+self.offset]), "x") + format(ord(line[11+self.offset]), "x"), 16)
            self.battery_msg.data.append(timeleft)
            # print ("timeleft = " + str(datetime.timedelta(seconds=timeleft)) + " restant")

            # Charging state
            if current_float > 15.0 and current_float < 21.0:
                self.charging_buffer.append(1)
            elif percentage == 100.0 and timeleft < 200.0:
                self.charging_buffer.append(1)
            elif voltage > 58.0:
                self.charging_buffer.append(1)
            else:
                self.charging_buffer.append(0)
            charging_sum = 0
            for i in range(len(self.charging_buffer)):
                charging_sum += self.charging_buffer[i]
            if charging_sum >= 10:
                charging = 1
            else:
                charging = 0
            self.battery_msg.data.append(charging)

            # Charge complete
            if timeleft == 0.0 and percentage == 100.0:
                charge_complete = 1
            else:
                charge_complete = 0
            self.battery_msg.data.append(charge_complete) 
            
            #remember last data up to 10 times successively
            self.lastData = self.battery_msg.data[:]
            self.successiveErrCount = 0
            if self.bad_data_count >= 20 :
                rospy.logwarn("Serial"+self.type+"/createBatteryMessage - data came back -> bad_data_count = 0 ") 
            self.bad_data_count = 0
            if self.debug:
                rospy.logdebug("Serial"+self.type+"/createBatteryMessage - battery_msg : " + str(self.battery_msg.data))
                rospy.logdebug("Serial"+self.type+"/createBatteryMessage - lastData : " + str(self.lastData))
        except Exception as e:
            rospy.logwarn("Serial"+self.type +"/createBatteryMessage - Error is : " + str(e))

    def publishBatteryLED(self):
        color = None
        # rospy.logwarn("publishBatteryLED - self.battery_msg.data is: " + str(self.battery_msg.data))
        if len(self.battery_msg.data) > 0:
            # convert the percent [0-100] to [0-255]
            p = self.battery_msg.data[0] * 2.55

            # handle the battery alert
            if(self._low_battery_alert):
                color = ColorRGBA(255.0 - p, p, 0, 500.0)
            # handles the normal case (degradé de couleur between red and green)
            elif(p > 0 and p <= 255):
                color = ColorRGBA(255.0 - p, p, 0, 0)
            # handles the no data case
            else:
                color = ColorRGBA(255.0, 128, 0, 1000)

        if (color != None):
            self.ros_pub_color_battery_.publish(color)
        else:
            rospy.logerr(
                "Serial"+self.type+"/publishBatteryLED - msg battery data is empty.")
            color = ColorRGBA(255.0, 0.0, 0, 0)
            self.ros_pub_color_battery_.publish(color)

    def _stop_reader(self):
        self._reader_alive = False
        self.receiver_thread.join()
        rospy.loginfo("Serial"+self.type +
                      "/_stop_reader - thread halted - ready to terminate")
        if self._ser is not None:
            self._ser.flushInput()
            self._ser.flushOutput()
            self._ser.close()

    def publishDiagnostics(self):
        with self.mutex_battery_msg:
            arr = DiagnosticArray()
            values = []
            values.append(            KeyValue("Percentage Left", str(self.battery_msg.data[0])))
            values.append(            KeyValue("Voltage",         str(self.battery_msg.data[1])))
            values.append(            KeyValue("Power",           str(self.battery_msg.data[2])))
            values.append(            KeyValue("Current",         str(self.battery_msg.data[3])))
            values.append(            KeyValue("Time Left",       str(self.battery_msg.data[4])))
            values.append(            KeyValue("Charging",        str(self.battery_msg.data[5])))
            values.append(            KeyValue("Charge complete", str(self.battery_msg.data[6])))
            values.append(            KeyValue("Alert Battery",   str(self._low_battery_alert)))

            if(self.battery_msg.data[1] < 40 and self._low_battery_alert):
                arr.status = [DiagnosticStatus(level=DiagnosticStatus.ERROR, name="Serial"+self.type, message="Error - Battery Critical", values=values)]
            elif(self._low_battery_alert):
                arr.status = [DiagnosticStatus(level=DiagnosticStatus.WARN, name="Serial"+self.type, message="Warning - Low Battery", values=values)]
            else:
                arr.status = [DiagnosticStatus(level=DiagnosticStatus.OK, name="Serial"+self.type, message="OK", values=values)]
            
            arr.header.stamp = rospy.Time.now()
            self.pub_diagnostics.publish(arr)

    def main_loop(self, timer):
        """
        Main loop that is threaded to publish the diagnostic feedback
        """
        try:
            if not rospy.is_shutdown():
                try:
                    if self.debug:
                        rospy.loginfo_throttle(5, "Serial"+self.type+"/main_loop - feedback message is being built.")
                    # rospy.loginfo("SerialCoulombmeter/main_loop - feedback message is being built.")

                    
                    with self.mutex_battery_msg:
                        # publish battery data
                        if len(self.battery_msg.data) == self.battery_msg.layout.dim[0].size:
                            try:
                                self.ros_pub_battery_data.publish(self.battery_msg)
                                # publish alert battery if need be
                                if self._low_battery_alert != self._low_battery_alert_previous:
                                    self.ros_pub_low_battery_alert.publish(
                                        self._low_battery_alert)
                                    self._low_battery_alert_previous = self._low_battery_alert
                            except Exception as e:
                                rospy.logerr("Serial"+self.type +"/main_loop/# publish battery data - Error is : " + str(e))

                            # publish Diagnostics
                            # try:
                            #     self.publishDiagnostics()
                            # except Exception as e:
                            #     rospy.logerr("Serial"+self.type +"/main_loop/#publish Diagnostics - Error is : " + str(e))

                            # publish LED battery state
                            try:
                                self.publishBatteryLED()
                            except Exception as e:
                                rospy.logerr("Serial"+self.type +"/main_loop/#publish LED battery state - Error is : " + str(e))                     
                        else:
                            rospy.logerr("Serial" + self.type + "/main_loop - Bad len of data array ! - Len : " + str(len(self.battery_msg.data)))
                except Exception as e:
                    rospy.logerr("Serial"+self.type + "/main_loop - Error is : " + str(e))
        except Exception as e:
            rospy.logwarn("Serial"+self.type + "/main_loop - shutdown called. Error is : " + str(e))